@extends('layouts.app')

@extends('layouts.navbar')

@section('content')
  <body> 
      <div class="container-fluid">
          <div class="row">
           <div class="col-md-8 col-md-offset-2 text-center">   
          
    <h1>THIS PAGE IS CURRENTLY UNDER CONSTRUCTION</h1>
           </div>
          </div><br />
          <div class="col-md-8 col-md-offset-2">
              <img src="images/May-14-2016.jpg" class="img-responsive center-block" style="max-width: 65%">
              </div><br />
          <div class="col-md-8 col-md-offset-2 text-center">
              <h3>Please Like and Follow us on <a href="https://www.facebook.com/Armed-With-Honor-397231353786576/"> FaceBook!</a></h3>
              <h6>For booking info, inquire at <a href="mailto:booking@armedwithhonor.com">booking@armedwithhonor.com</a></h6>
          </div><br />
      </div>
    
    @endsection