@extends('layouts.admin')

@section('content')
<div class='center-block'><h1>Please Log In To Continue</h1></div>
@endsection